const roles = ["Software Engineering Student", "Object-Oriented Systems Builder", "Full-Stack & ML Explorer"];
const roleEl = document.getElementById('roleType');
let rIndex = 0, cIndex = 0, deleting = false;
function roleTick(){
  const current = roles[rIndex];
  if(!deleting){
    cIndex++;
    roleEl.textContent = current.slice(0, cIndex);
    if(cIndex === current.length){ deleting = true; setTimeout(roleTick, 1600); return; }
  } else {
    cIndex--;
    roleEl.textContent = current.slice(0, cIndex);
    if(cIndex === 0){ deleting = false; rIndex = (rIndex + 1) % roles.length; }
  }
  setTimeout(roleTick, deleting ? 26 : 42);
}
roleTick();

function typeElement(el){
  const text = el.textContent;
  const speed = parseInt(el.dataset.speed || '20', 10);
  el.textContent = '';
  el.classList.add('typed');
  const cursor = document.createElement('span');
  cursor.className = 'type-cursor';
  el.after(cursor);
  let i = 0;
  const timer = setInterval(() => {
    el.textContent += text[i];
    i++;
    if(i >= text.length){
      clearInterval(timer);
      setTimeout(() => cursor.classList.add('done'), 500);
    }
  }, speed);
}

const revealEls = document.querySelectorAll('.reveal, .reveal-stagger');
if('IntersectionObserver' in window){
  const io = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if(entry.isIntersecting){
        entry.target.classList.add('is-visible');
        const t = entry.target.querySelector ? entry.target.querySelector('.type-target') : null;
        if(t && !t.classList.contains('typed')) typeElement(t);
        io.unobserve(entry.target);
      }
    });
  }, { threshold: 0.15, rootMargin: '0px 0px -50px 0px' });
  revealEls.forEach(el => io.observe(el));
} else {
  revealEls.forEach(el => el.classList.add('is-visible'));
  document.querySelectorAll('.type-target').forEach(el => el.classList.add('typed'));
}
