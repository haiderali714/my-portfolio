# Haider Ali — Portfolio

Personal portfolio website for Haider Ali, BS Software Engineering student at The University of Lahore.

**Tech:** plain HTML, CSS and vanilla JavaScript. No framework, no build step, no dependencies.

## Project structure

```
haider-ali-portfolio/
├── index.html
├── css/
│   └── style.css
├── js/
│   └── main.js
├── assets/
│   └── images/
│       └── avatar.jpg
├── .gitignore
├── .nojekyll
└── README.md
```

## Run locally

Open `index.html` in any browser, or serve the folder:

```bash
python3 -m http.server 8000
# then visit http://localhost:8000
```

## Deploy on GitHub Pages

1. Create a new repository on GitHub, e.g. `haider-ali-portfolio`.
2. Upload all files and folders from this project (keep the structure; `index.html` stays in the root).
3. Go to **Settings → Pages**.
4. Under **Build and deployment**, set **Source** to *Deploy from a branch*, choose **main** and **/ (root)**, then Save.
5. After 1–2 minutes the site is live at `https://<your-username>.github.io/haider-ali-portfolio/`.

Or from the command line:

```bash
git init
git add .
git commit -m "Initial portfolio"
git branch -M main
git remote add origin https://github.com/<your-username>/haider-ali-portfolio.git
git push -u origin main
```

## Deploy elsewhere

Netlify, Vercel and Cloudflare Pages all work by dragging the folder in or connecting the repo. Build command: none. Output directory: the repo root.

## Customising

- Text and sections: `index.html`
- Colours, fonts, spacing: CSS variables at the top of `css/style.css`
- Typing effect and scroll reveals: `js/main.js`
- Profile photo: replace `assets/images/avatar.jpg` (square image works best)
